package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private RadioGroup grupoPerguntas1, grupoPerguntas2, grupoperguntas3;
    private Button enviarButton, limparButton;
    private TextView resultText, resposta1, resposta2, resposta3;
    private int[] questoesCorretas = {R.id.radioQuestao1Alt2, R.id.radioQuestao2Alt5, R.id.radioQuestao3Alt2};
    private int pontuacao = 0;

    private void restartQuiz() {
        grupoPerguntas1.clearCheck();
        grupoPerguntas2.clearCheck();
        grupoperguntas3.clearCheck();

        pontuacao = 0;

        resultText.setText("");


        enviarButton.setEnabled(true);
        resposta1.setText("");
        resposta2.setText("");
        resposta3.setText("");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        grupoPerguntas1 = findViewById(R.id.questao1);
        grupoPerguntas2 = findViewById(R.id.questao2);
        grupoperguntas3 = findViewById(R.id.questao3);
        enviarButton = findViewById(R.id.buttonEnviar);
        limparButton = findViewById(R.id.buttonLimpar);
        resultText = findViewById(R.id.txtTotal);
        resposta1 = findViewById(R.id.txtResposta1);
        resposta2 = findViewById(R.id.txtResposta2);
        resposta3 = findViewById(R.id.txtResposta3);


        enviarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswers();
            }
        });

        limparButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                restartQuiz();
            }
        });
    }

    private void checkAnswers() {
        pontuacao = 0;

        if (isCorrectAnswer(grupoPerguntas1, questoesCorretas[0])) {
            pontuacao++;
            resposta1.setText("Certo");
        } else {
            resposta1.setText("O correto é America do Sul");
        }

        if (isCorrectAnswer(grupoPerguntas2, questoesCorretas[1])) {
            pontuacao++;
            resposta2.setText("Certo");
        } else {
            resposta2.setText("Nenhuma das alternativas");
        }

        if (isCorrectAnswer(grupoperguntas3, questoesCorretas[2])) {
            pontuacao++;
            resposta3.setText("Certo");
        } else {
            resposta3.setText("O correto é 1500");
        }

        resultText.setText("Pontuação: " + pontuacao + "/" + questoesCorretas.length);
        enviarButton.setEnabled(false); 
    }

    private boolean isCorrectAnswer(RadioGroup group, int correctId) {
        int selectedId = group.getCheckedRadioButtonId();
        return selectedId == correctId;
    }
}
